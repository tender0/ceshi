// API 配置 - 部署时修改为你的服务器地址
export const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://45.62.104.227:3001'
